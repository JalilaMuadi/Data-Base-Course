/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package carRentalManagment;

import java.sql.*;
import java.sql.Connection;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author Owner's
 */
public class Cars extends javax.swing.JFrame {

    /**
     * Creates new form Cars
     */
    public Cars() {
        initComponents();
        tableUpdate();
    }

    @SuppressWarnings("unchecked")
    Connection con = null;
    PreparedStatement pst = null;
    ResultSet rs = null;

    private void tableUpdate() {
        int c;
        try {
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrentalsystem", "root", "2002");
            
            pst = con.prepareStatement("SELECT * FROM vehicle ORDER BY carreg ASC"); // Modified query
            rs = pst.executeQuery();
            ResultSetMetaData rd = rs.getMetaData();
            c = rd.getColumnCount();
            DefaultTableModel df = (DefaultTableModel) carsTable.getModel();
            df.setRowCount(0);
            while (rs.next()) {
                Vector v2 = new Vector();
                for (int i = 1; i <= c; i++) {
                    v2.add(rs.getString("carreg"));
                    v2.add(rs.getString("brand"));
                    v2.add(rs.getString("model"));
                    v2.add(rs.getString("status"));
                    v2.add(rs.getInt("dailyPrice"));
                }
                df.addRow(v2);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean isCarregAlreadyExists(String carreg) throws SQLException {
        // Check if carreg already exists in the table
        PreparedStatement checkStatement = con.prepareStatement("SELECT COUNT(*) FROM vehicle WHERE carreg = ?");
        checkStatement.setString(1, carreg);
        ResultSet resultSet = checkStatement.executeQuery();
        resultSet.next();
        int count = resultSet.getInt(1);
        return count > 0;
    }

    private void clearCarFields() {
        carIDTb.setText("");
        brandTb.setText("");
        modelTb.setText("");
        statusCb.setSelectedIndex(-1);
        dPriceTb.setText("");
    }
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        carIDTb = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        brandTb = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        modelTb = new javax.swing.JTextField();
        dPriceTb = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        statusCb = new javax.swing.JComboBox<>();
        saveBtn = new javax.swing.JButton();
        editBtn = new javax.swing.JButton();
        resetBtn = new javax.swing.JButton();
        deleteBtn = new javax.swing.JButton();
        jScrollPane1 = new javax.swing.JScrollPane();
        carsTable = new javax.swing.JTable();
        jLabel7 = new javax.swing.JLabel();
        logoutLabel = new javax.swing.JLabel();
        clickCustomerlabel = new javax.swing.JLabel();
        clickRentCarLabel = new javax.swing.JLabel();
        clickReturnCarLabel = new javax.swing.JLabel();
        clickQueriesLable = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        jPanel1 = new javax.swing.JPanel();
        ClosePageLabel = new javax.swing.JLabel();
        MainPageLable = new javax.swing.JLabel();
        searchLabel = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Manges Car Page");
        setBackground(new java.awt.Color(255, 255, 255));
        setMinimumSize(new java.awt.Dimension(1050, 730));
        setUndecorated(true);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        jLabel1.setText("Car Reg Num");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 80, -1, -1));

        jLabel2.setFont(new java.awt.Font("Century Gothic", 1, 22)); // NOI18N
        jLabel2.setText("Cars List");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(600, 210, -1, -1));

        carIDTb.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        carIDTb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                carIDTbActionPerformed(evt);
            }
        });
        getContentPane().add(carIDTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 100, 149, -1));

        jLabel3.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        jLabel3.setText("Brand");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 80, -1, -1));

        brandTb.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        brandTb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                brandTbActionPerformed(evt);
            }
        });
        getContentPane().add(brandTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(430, 100, 132, -1));

        jLabel4.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        jLabel4.setText("Model");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 80, -1, -1));

        modelTb.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        modelTb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modelTbActionPerformed(evt);
            }
        });
        getContentPane().add(modelTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 100, 132, -1));

        dPriceTb.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        dPriceTb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                dPriceTbActionPerformed(evt);
            }
        });
        getContentPane().add(dPriceTb, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 100, 132, -1));

        jLabel6.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        jLabel6.setText("Status");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 80, -1, -1));

        statusCb.setFont(new java.awt.Font("Century Schoolbook", 0, 12)); // NOI18N
        statusCb.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Booked", "Available" }));
        statusCb.setSelectedItem(null);
        statusCb.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                statusCbActionPerformed(evt);
            }
        });
        getContentPane().add(statusCb, new org.netbeans.lib.awtextra.AbsoluteConstraints(730, 100, 132, -1));

        saveBtn.setBackground(new java.awt.Color(238, 234, 234));
        saveBtn.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        saveBtn.setText("Save");
        saveBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                saveBtnActionPerformed(evt);
            }
        });
        getContentPane().add(saveBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 150, 100, -1));

        editBtn.setBackground(new java.awt.Color(238, 234, 234));
        editBtn.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        editBtn.setText("Edit");
        editBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                editBtnActionPerformed(evt);
            }
        });
        getContentPane().add(editBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 150, 100, -1));

        resetBtn.setBackground(new java.awt.Color(238, 234, 234));
        resetBtn.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        resetBtn.setText("Reset");
        resetBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                resetBtnActionPerformed(evt);
            }
        });
        getContentPane().add(resetBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(750, 150, 100, -1));

        deleteBtn.setBackground(new java.awt.Color(238, 234, 234));
        deleteBtn.setFont(new java.awt.Font("Century Gothic", 1, 16)); // NOI18N
        deleteBtn.setText("Delete");
        deleteBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                deleteBtnActionPerformed(evt);
            }
        });
        getContentPane().add(deleteBtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(630, 150, 100, -1));

        carsTable.setFont(new java.awt.Font("Century Gothic", 0, 12)); // NOI18N
        carsTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Car Reg Num ", "Brand", "Model ", "Statues", "Daily Price"
            }
        ));
        carsTable.setRowHeight(25);
        carsTable.setSelectionBackground(new java.awt.Color(255, 255, 255));
        jScrollPane1.setViewportView(carsTable);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(270, 250, 740, 390));

        jLabel7.setFont(new java.awt.Font("Modern No. 20", 1, 30)); // NOI18N
        jLabel7.setText("Manges Cars");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 30, -1, 30));

        logoutLabel.setFont(new java.awt.Font("Comic Sans MS", 1, 14)); // NOI18N
        logoutLabel.setForeground(new java.awt.Color(255, 255, 255));
        logoutLabel.setText("Logout");
        logoutLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                logoutLabelMouseClicked(evt);
            }
        });
        getContentPane().add(logoutLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 700, 50, 20));

        clickCustomerlabel.setFont(new java.awt.Font("Gabriola", 1, 30)); // NOI18N
        clickCustomerlabel.setForeground(new java.awt.Color(255, 255, 255));
        clickCustomerlabel.setText("Customers");
        clickCustomerlabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickCustomerlabelMouseClicked(evt);
            }
        });
        getContentPane().add(clickCustomerlabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 130, 110, 50));

        clickRentCarLabel.setFont(new java.awt.Font("Gabriola", 1, 30)); // NOI18N
        clickRentCarLabel.setForeground(new java.awt.Color(255, 255, 255));
        clickRentCarLabel.setText("Rent Car");
        clickRentCarLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickRentCarLabelMouseClicked(evt);
            }
        });
        getContentPane().add(clickRentCarLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 180, 110, 50));

        clickReturnCarLabel.setFont(new java.awt.Font("Gabriola", 1, 30)); // NOI18N
        clickReturnCarLabel.setForeground(new java.awt.Color(255, 255, 255));
        clickReturnCarLabel.setText("Return Car");
        clickReturnCarLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickReturnCarLabelMouseClicked(evt);
            }
        });
        getContentPane().add(clickReturnCarLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 120, 50));

        clickQueriesLable.setFont(new java.awt.Font("Gabriola", 1, 30)); // NOI18N
        clickQueriesLable.setForeground(new java.awt.Color(255, 255, 255));
        clickQueriesLable.setText("Employees");
        clickQueriesLable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                clickQueriesLableMouseClicked(evt);
            }
        });
        getContentPane().add(clickQueriesLable, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 280, 110, 50));

        jLabel9.setFont(new java.awt.Font("Century Schoolbook", 0, 16)); // NOI18N
        jLabel9.setText("Daily Price");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(880, 80, -1, -1));

        jLabel8.setIcon(new javax.swing.ImageIcon("C:\\Users\\Owner's\\Documents\\NetBeansProjects\\testfx\\side11.jpg")); // NOI18N
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 230, 750));

        jPanel1.setBackground(new java.awt.Color(255, 255, 255));
        jPanel1.setForeground(new java.awt.Color(255, 255, 255));

        ClosePageLabel.setFont(new java.awt.Font("Berlin Sans FB Demi", 1, 16)); // NOI18N
        ClosePageLabel.setText("X");
        ClosePageLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                ClosePageLabelMouseClicked(evt);
            }
        });

        MainPageLable.setIcon(new javax.swing.ImageIcon("C:\\Users\\Owner's\\Documents\\NetBeansProjects\\testfx\\main11.png")); // NOI18N
        MainPageLable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                MainPageLableMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(MainPageLable)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 782, Short.MAX_VALUE)
                .addComponent(ClosePageLabel)
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addGap(0, 1, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(ClosePageLabel)
                    .addComponent(MainPageLable)))
        );

        getContentPane().add(jPanel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 0, 820, 20));

        searchLabel.setFont(new java.awt.Font("Century Gothic", 1, 12)); // NOI18N
        searchLabel.setText("Search");
        searchLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                searchLabelMouseClicked(evt);
            }
        });
        getContentPane().add(searchLabel, new org.netbeans.lib.awtextra.AbsoluteConstraints(260, 130, -1, 20));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void carIDTbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_carIDTbActionPerformed

    }//GEN-LAST:event_carIDTbActionPerformed

    private void brandTbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_brandTbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_brandTbActionPerformed

    private void dPriceTbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_dPriceTbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_dPriceTbActionPerformed

    private void statusCbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_statusCbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_statusCbActionPerformed

    private void saveBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_saveBtnActionPerformed

        if (carIDTb.getText().isEmpty() || brandTb.getText().isEmpty() || modelTb.getText().isEmpty()
                || dPriceTb.getText().isEmpty() || statusCb.getSelectedIndex() == -1) {
            JOptionPane.showMessageDialog(this, "Missing Information! Try again :)");

        } else {
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrentalsystem", "root", "2002");
                
                // Check if carreg already exists
                if (isCarregAlreadyExists(carIDTb.getText())) {
                    JOptionPane.showMessageDialog(this, "Car Registration Number already exists! Please use a different one.");
                } else {
                    PreparedStatement add = con.prepareStatement("INSERT INTO vehicle(carreg, brand, model, status, dailyPrice) VALUES (?, ?, ?, ?, ?)");
                    add.setString(1, carIDTb.getText());
                    add.setString(2, brandTb.getText());
                    add.setString(3, modelTb.getText());
                    add.setString(4, statusCb.getSelectedItem().toString());
                    add.setInt(5, Integer.parseInt(dPriceTb.getText()));
                    add.executeUpdate();
                    JOptionPane.showMessageDialog(this, "Car Added Successfully!");
                    tableUpdate();
                    clearCarFields();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_saveBtnActionPerformed

    private void editBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_editBtnActionPerformed
        if (carIDTb.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Car Registration Number to edit.");
        } else {
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrentalsystem", "root", "2002");

                // Check if the car registration number exists
                if (isCarregAlreadyExists(carIDTb.getText())) {
                    // Retrieve car information
                    String updateQuery = "UPDATE vehicle SET brand=?, model=?, status=?, dailyPrice=? WHERE carreg=?";
                    PreparedStatement updateCar = con.prepareStatement(updateQuery);

                    updateCar.setString(1, brandTb.getText());
                    updateCar.setString(2, modelTb.getText());
                    updateCar.setString(3, statusCb.getSelectedItem().toString());
                    updateCar.setInt(4, Integer.parseInt(dPriceTb.getText()));
                    updateCar.setString(5, carIDTb.getText());

                    int rowsAffected = updateCar.executeUpdate();

                    if (rowsAffected > 0) {
                        JOptionPane.showMessageDialog(this, "Car information updated successfully!");
                        tableUpdate(); // Update the table with the new data
                        clearCarFields();
                    } else {
                        JOptionPane.showMessageDialog(this, "Car not found.");
                        clearCarFields();
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Car Registration Number does not exist.");
                    clearCarFields();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_editBtnActionPerformed

    private void resetBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_resetBtnActionPerformed
        clearCarFields();
    }//GEN-LAST:event_resetBtnActionPerformed

    private void deleteBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_deleteBtnActionPerformed
        // TODO add your handling code here:
        if (carIDTb.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Car Registration Number to delete.");
        } else {
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrentalsystem", "root", "2002");

                // Check if the car registration number exists
                if (isCarregAlreadyExists(carIDTb.getText())) {
                    // Confirm deletion with user
                    int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this car?", "Confirmation", JOptionPane.YES_NO_OPTION);
                    if (choice == JOptionPane.YES_OPTION) {
                        // Delete associated records in emp_involve_car table
                        String deleteCarsQuery = "DELETE FROM emp_involve_car WHERE carreg=?";
                        PreparedStatement deleteCars = con.prepareStatement(deleteCarsQuery);
                        deleteCars.setString(1, carIDTb.getText());
                        deleteCars.executeUpdate();
                        // Delete car
                        String deleteQuery = "DELETE FROM vehicle WHERE carreg=?";
                        PreparedStatement deleteCar = con.prepareStatement(deleteQuery);
                        deleteCar.setString(1, carIDTb.getText());

                        int rowsAffected = deleteCar.executeUpdate();

                        if (rowsAffected > 0) {
                            JOptionPane.showMessageDialog(this, "Car deleted successfully!");
                            tableUpdate(); // Update the table with the new data
                            clearCarFields();
                        } else {
                            JOptionPane.showMessageDialog(this, "Car not found.");
                            clearCarFields();
                        }
                    }
                } else {
                    JOptionPane.showMessageDialog(this, "Car Registration Number does not exist.");
                    clearCarFields();
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_deleteBtnActionPerformed

    private void modelTbActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modelTbActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_modelTbActionPerformed

    private void logoutLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_logoutLabelMouseClicked
        new login().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_logoutLabelMouseClicked

    private void clickCustomerlabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clickCustomerlabelMouseClicked
        // TODO add your handling code here:
        new Customer().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_clickCustomerlabelMouseClicked

    private void clickRentCarLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clickRentCarLabelMouseClicked
        // TODO add your handling code here:
        new Rents().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_clickRentCarLabelMouseClicked

    private void clickReturnCarLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clickReturnCarLabelMouseClicked
        // TODO add your handling code here:
        new Returns().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_clickReturnCarLabelMouseClicked

    private void clickQueriesLableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_clickQueriesLableMouseClicked
        // TODO add your handling code here:
        new loginEmployeePage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_clickQueriesLableMouseClicked

    private void ClosePageLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_ClosePageLabelMouseClicked
        System.exit(0);
    }//GEN-LAST:event_ClosePageLabelMouseClicked

    private void MainPageLableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_MainPageLableMouseClicked
        new mainPage().setVisible(true);
        this.dispose();
    }//GEN-LAST:event_MainPageLableMouseClicked

    private void searchLabelMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_searchLabelMouseClicked
        if (carIDTb.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter Car Registration Number to search.");
        } else {
            try {
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/carrentalsystem", "root", "2002");

                // Check if the car registration number exists
                if (isCarregAlreadyExists(carIDTb.getText())) {
                    // Retrieve car information
                    String query = "SELECT * FROM vehicle WHERE carreg = ?";
                    PreparedStatement searchCar = con.prepareStatement(query);
                    searchCar.setString(1, carIDTb.getText());
                    ResultSet result = searchCar.executeQuery();

                    if (result.next()) {
                        // Set car information to textboxes
                        brandTb.setText(result.getString("brand"));
                        modelTb.setText(result.getString("model"));
                        statusCb.setSelectedItem(result.getString("status"));
                        dPriceTb.setText(Integer.toString(result.getInt("dailyPrice")));

                        // You can add additional logic here to display or handle car-related information
                        // For example, if you have another table showing car involvement details, you can populate it
                    } else {
                        JOptionPane.showMessageDialog(this, "Car not found.");
                        // You may choose to clear the form or take other appropriate actions
                        clearCarFields();
                    }
                } else {
                    clearCarFields();
                    JOptionPane.showMessageDialog(this, "Car Registration Number does not exist.");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }//GEN-LAST:event_searchLabelMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Cars.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Cars.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Cars.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Cars.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Cars().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel ClosePageLabel;
    private javax.swing.JLabel MainPageLable;
    private javax.swing.JTextField brandTb;
    private javax.swing.JTextField carIDTb;
    private javax.swing.JTable carsTable;
    private javax.swing.JLabel clickCustomerlabel;
    private javax.swing.JLabel clickQueriesLable;
    private javax.swing.JLabel clickRentCarLabel;
    private javax.swing.JLabel clickReturnCarLabel;
    private javax.swing.JTextField dPriceTb;
    private javax.swing.JButton deleteBtn;
    private javax.swing.JButton editBtn;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel logoutLabel;
    private javax.swing.JTextField modelTb;
    private javax.swing.JButton resetBtn;
    private javax.swing.JButton saveBtn;
    private javax.swing.JLabel searchLabel;
    private javax.swing.JComboBox<String> statusCb;
    // End of variables declaration//GEN-END:variables
}
