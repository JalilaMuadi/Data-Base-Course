package carRentalManagment;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Date;
import java.util.concurrent.TimeUnit;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import com.toedter.calendar.JDateChooser;

public class DateDifferenceCalculator extends JFrame {
    private JDateChooser dateChooser1;
    private JDateChooser dateChooser2;
    private JButton calculateButton;

    public DateDifferenceCalculator() {
        initComponents();
    }

    private void initComponents() {
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 150);
        
        dateChooser1 = new JDateChooser();
        dateChooser2 = new JDateChooser();
        calculateButton = new JButton("Calculate Difference");

        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                calculateDateDifference();
            }
        });

        JPanel panel = new JPanel();
        panel.add(dateChooser1);
        panel.add(dateChooser2);
        panel.add(calculateButton);

        add(panel);
    }

    private void calculateDateDifference() {
        Date startDate = dateChooser1.getDate();
        Date endDate = dateChooser2.getDate();

        if (startDate != null && endDate != null) {
            long differenceInMillis = endDate.getTime() - startDate.getTime();
            long differenceInDays = TimeUnit.MILLISECONDS.toDays(differenceInMillis);

            System.out.println("Difference in days: " + differenceInDays);
        } else {
            System.out.println("Please select both start and end dates.");
        }
    }

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DateDifferenceCalculator().setVisible(true);
            }
        });
    }
}
