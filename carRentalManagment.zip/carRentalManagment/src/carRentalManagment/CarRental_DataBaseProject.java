package carRentalManagment;

import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import javafx.application.Application;
import javafx.stage.Stage;

public class CarRental_DataBaseProject extends Application {

    public static void main(String[] args) {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mysql", "root", "2002");
            System.out.println(con);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(CarRental_DataBaseProject.class.getName()).log(Level.SEVERE, null, ex);
        }

        // Launch the JavaFX application
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        // Open the login window
        new login().setVisible(true);

        // Close the current stage
        stage.close();
    }
}
