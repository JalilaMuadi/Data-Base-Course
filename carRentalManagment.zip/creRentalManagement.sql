CREATE DATABASE  IF NOT EXISTS `carrentalsystem` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `carrentalsystem`;
-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: localhost    Database: carrentalsystem
-- ------------------------------------------------------
-- Server version	5.7.44-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `car_return_relation`
--

DROP TABLE IF EXISTS `car_return_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `car_return_relation` (
  `carreg` varchar(15) NOT NULL,
  `return_id` int(11) NOT NULL,
  PRIMARY KEY (`carreg`,`return_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `car_return_relation`
--

LOCK TABLES `car_return_relation` WRITE;
/*!40000 ALTER TABLE `car_return_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `car_return_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_rent_relation`
--

DROP TABLE IF EXISTS `cust_rent_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_rent_relation` (
  `cust_id` int(11) NOT NULL,
  `rent_id` int(11) NOT NULL,
  PRIMARY KEY (`cust_id`,`rent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_rent_relation`
--

LOCK TABLES `cust_rent_relation` WRITE;
/*!40000 ALTER TABLE `cust_rent_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `cust_rent_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cust_return_relation`
--

DROP TABLE IF EXISTS `cust_return_relation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cust_return_relation` (
  `cust_id` int(11) NOT NULL,
  `return_id` int(11) NOT NULL,
  PRIMARY KEY (`cust_id`,`return_id`),
  KEY `return_id_idx` (`return_id`),
  CONSTRAINT `cust_id` FOREIGN KEY (`cust_id`) REFERENCES `customer` (`cust_ID`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `return_id` FOREIGN KEY (`return_id`) REFERENCES `return_t` (`return_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cust_return_relation`
--

LOCK TABLES `cust_return_relation` WRITE;
/*!40000 ALTER TABLE `cust_return_relation` DISABLE KEYS */;
/*!40000 ALTER TABLE `cust_return_relation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `cust_ID` int(11) NOT NULL,
  `cust_name` varchar(45) DEFAULT NULL,
  `address` varchar(45) DEFAULT NULL,
  `phone` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`cust_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (1,'Mohammad','Ramallah','05957072476'),(2,'Aram','Ramallah','05953652147'),(3,'Yazan','Nablus','05953756647'),(4,'Ouda','KafrMalik','05954732540'),(5,'Islam','Hebron','05669874325'),(6,'Ahmad','Genen','05669874362'),(7,'Omar ','Ramallah','05998876225'),(8,'Sami','Jerusalem','0595240477');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emp_involve_car`
--

DROP TABLE IF EXISTS `emp_involve_car`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emp_involve_car` (
  `carreg` varchar(15) NOT NULL,
  `emp_id` int(11) NOT NULL,
  PRIMARY KEY (`emp_id`,`carreg`),
  KEY `carreg_idx` (`carreg`),
  CONSTRAINT `carreg` FOREIGN KEY (`carreg`) REFERENCES `vehicle` (`carreg`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `emp_id` FOREIGN KEY (`emp_id`) REFERENCES `employee` (`emp_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emp_involve_car`
--

LOCK TABLES `emp_involve_car` WRITE;
/*!40000 ALTER TABLE `emp_involve_car` DISABLE KEYS */;
/*!40000 ALTER TABLE `emp_involve_car` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `employee` (
  `emp_id` int(11) NOT NULL,
  `emp_name` varchar(30) DEFAULT NULL,
  `emp_address` varchar(45) DEFAULT NULL,
  `emp_phone` varchar(15) DEFAULT NULL,
  `salary` int(11) DEFAULT NULL,
  PRIMARY KEY (`emp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'Sawsan','Ramallah','0596352438',8000),(2,'janna','Nablus','0595313165',7500),(3,'jalila','Kafrmalik','0595765877',5000);
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rent`
--

DROP TABLE IF EXISTS `rent`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rent` (
  `rent_id` int(11) NOT NULL,
  `car_reg` varchar(15) NOT NULL,
  `cust_name` varchar(45) DEFAULT NULL,
  `rent_date` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `reg_fees` int(11) DEFAULT NULL,
  PRIMARY KEY (`rent_id`,`car_reg`),
  KEY `car_reg_idx` (`car_reg`),
  CONSTRAINT `car_reg` FOREIGN KEY (`car_reg`) REFERENCES `vehicle` (`carreg`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rent`
--

LOCK TABLES `rent` WRITE;
/*!40000 ALTER TABLE `rent` DISABLE KEYS */;
/*!40000 ALTER TABLE `rent` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `return_t`
--

DROP TABLE IF EXISTS `return_t`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `return_t` (
  `return_id` int(11) NOT NULL,
  `carreg` varchar(15) DEFAULT NULL,
  `cust_name` varchar(45) DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `delay` int(11) DEFAULT NULL,
  `fine` int(11) DEFAULT NULL,
  PRIMARY KEY (`return_id`),
  KEY `carreg_idx` (`carreg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `return_t`
--

LOCK TABLES `return_t` WRITE;
/*!40000 ALTER TABLE `return_t` DISABLE KEYS */;
/*!40000 ALTER TABLE `return_t` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `vehicle`
--

DROP TABLE IF EXISTS `vehicle`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `vehicle` (
  `carreg` varchar(15) NOT NULL,
  `brand` varchar(15) NOT NULL,
  `model` varchar(15) NOT NULL,
  `status` varchar(15) NOT NULL,
  `dailyPrice` int(11) NOT NULL,
  PRIMARY KEY (`carreg`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vehicle`
--

LOCK TABLES `vehicle` WRITE;
/*!40000 ALTER TABLE `vehicle` DISABLE KEYS */;
INSERT INTO `vehicle` VALUES ('C001','HONDA','ACCORD','Available',85),('C002','TOYOTA','CAMRY','Available',75),('C003','HONDA','CIVIC','Available',100),('C004','HYUNDAI','SONATA','Available',90),('C005','CHEVROLET','MALIBU','Available',120),('C006','BMU','X5','Available',220),('C007','BMW','3 SERIES','Available',180),('C008','MERCEDES','G-CLASS','Available',500),('C009','MERCEDES','GLC COUPE','Available',250),('C010','MERCEDES','E-CLASS','Available',190),('C011','BMW','7 SERIES','Available',220),('C012','AUDI','A4','Available',130),('C013','FERRARI','488 GTB','Available',400),('C014','FORD','MUSTANG','Available',200),('C015','JEEP','WRANGLER','Available',230),('C016','MAZDA','CX-5','Available',70),('C017','FERRARI','F8 TRIBUTO','Available',500),('C018','FORD','EXPLORER','Available',250),('C019','JEEP','CHEROKEE','Available',230);
/*!40000 ALTER TABLE `vehicle` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-25 20:27:52
